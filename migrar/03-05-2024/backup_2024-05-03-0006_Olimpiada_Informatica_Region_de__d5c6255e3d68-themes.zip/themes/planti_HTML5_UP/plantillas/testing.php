<?php
/*
Template Name: Plantilla test
*/
?>


<!-- Esta pagina es fea, pero al igual que el cuerpo humano en su interior, feo, pero util -->

<!-- Miau! ≽^•⩊•^≼ -->
<a href="/create_tables.php">Pulsa aqui para crear las tablas</a>
<p>AVISO: Pulsar este boton tirara las tablas, y luego, las volvera a crear. Haga una copia de seguridad antes de hacer esto si no quiere perder los datos</p>
<a href="/table_seeder.php">Pulsa aqui para llenar las tablas de datos de prueba para probar cosas</a>
<p>AVISO: Pulsar el boton borrara todos los registros que tenga la base de datos</p>
<a href="/wp-admin">Pulsa aqui para volver a wp-admin</a>
